import logo from './logo.svg';
import './App.css';
import MainPage from './components/MainPage';
function App() {
  return (
    <div className="App">
       <MainPage></MainPage>
    </div>
  );
}

export default App;
