import React from "react";
import "./MainPage.css";
class MainPage extends React.Component {
  state = {
    TempData: {},
    type: "",
    ToDo: [
      { id: 1, value: "Buy medicines" },
      { id: 2, value: "Go to the dentist" },
      { id: 3, value: "Do shoping" },
      { id: 4, value: "Call to the car service" },
    ],
    InProgress: [
      { id: 5, value: "Complete work report" },
      { id: 6, value: "Grandpa birthday" },
    ],
    Done: [
      { id: 7, value: "Book the table" },
      { id: 8, value: "Buy the suitcase" },
    ],
  };

  handleOnDrag = (e, id, type) => {
    if (type === "TODO") {
      const temp = this.state.ToDo.filter((x) => x.id === id);
      this.setState({ TempData: temp[0] });
      this.setState({ type: type });
    } else if (type === "INPROGRESS") {
      const temp = this.state.InProgress.filter((x) => x.id === id);
      this.setState({ TempData: temp[0] });
      this.setState({ type: type });
    } else if (type === "DONE") {
      const temp = this.state.Done.filter((x) => x.id === id);
      this.setState({ TempData: temp[0] });
      this.setState({ type: type });
    }
  };

  handleOnDrop = (e, type) => {
    if (this.state.type === "TODO") {
      const updated = [...this.state.ToDo];
      const index = this.state.ToDo.findIndex(
        (m) => m.id === this.state.TempData.id
      );
      updated.splice(index, 1);
      this.setState({ ToDo: updated });
    } else if (this.state.type === "INPROGRESS") {
      const updated = [...this.state.InProgress];
      const index = this.state.InProgress.findIndex(
        (m) => m.id === this.state.TempData.id
      );
      updated.splice(index, 1);
      this.setState({ InProgress: updated });
    } else if (this.state.type === "DONE") {
      const updated = [...this.state.Done];
      const index = this.state.Done.findIndex(
        (m) => m.id === this.state.TempData.id
      );
      updated.splice(index, 1);
      this.setState({ Done: updated });
    }
    if (type === "INPROGRESS") {
      const updateArr = [...this.state.InProgress];
      updateArr.push(this.state.TempData);
      this.setState({ InProgress: updateArr });
    } else if (type === "TODO") {
      const updateArr = [...this.state.ToDo];
      updateArr.push(this.state.TempData);
      this.setState({ ToDo: updateArr });
    } else if (type === "DONE") {
      const updateArr = [...this.state.Done];
      updateArr.push(this.state.TempData);
      this.setState({ Done: updateArr });
    }
    this.setState({ TempData: {} });
    this.setState({ type: "" });
  };
  handleDragOver = (e) => {
    e.preventDefault();
  };
  ToDoDiv = () => {
    console.log("ToDoDiv");
  };
  InProgressDiv = () => {
    console.log("InProgressDiv");
  };

  DoneDiv;
  render() {
    return (
      <>
        <div className="MainDiv">
          <table className="MainTable">
          <thead>
            <tr>
              <td className="HeaderTD">
                <button>New Task</button>
              </td>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td className="BodyTD">
                <div className="MainDiv2">
                  <div
                    onDrop={(e) => this.handleOnDrop(e, "TODO")}
                    onDragOver={(e) => this.handleDragOver(e)}
                    className="ToDoDiv"
                  >
                    <h3>To Do</h3>
                    {this.state.ToDo.map((data, index) => {
                      return (
                        <div
                          draggable
                          onDragStart={(e) =>
                            this.handleOnDrag(e, data.id, "TODO")
                          }
                          key={index}
                        >
                          {data.value}
                        </div>
                      );
                    })}
                  </div>
                  <div
                    name="INPROGRESS"
                    onDrop={(e) => this.handleOnDrop(e, "INPROGRESS")}
                    onDragOver={(e) => this.handleDragOver(e)}
                    className="InProgressDiv"
                  >
                    <h3>In Progress</h3>
                    {this.state.InProgress.map((data, index) => {
                      return (
                        <div
                          draggable
                          onDragStart={(e) =>
                            this.handleOnDrag(e, data.id, "INPROGRESS")
                          }
                          key={index}
                        >
                          {data.value}
                        </div>
                      );
                    })}
                  </div>
                  <div
                    onDrop={(e) => this.handleOnDrop(e, "DONE")}
                    onDragOver={(e) => this.handleDragOver(e)}
                    className="DoneDiv"
                  >
                    <h3>Done</h3>
                    {this.state.Done.map((data, index) => {
                      return (
                        <div
                          draggable
                          onDragStart={(e) =>
                            this.handleOnDrag(e, data.id, "DONE")
                          }
                          key={index}
                        >
                          {data.value}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </td>
            </tr>
            </tbody>
          </table>
        </div>
      </>
    );
  }
}

export default MainPage;
